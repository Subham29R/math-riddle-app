class RiddleQuestion {
  final String question;
  final String answer;
  final String? imagePath;

  RiddleQuestion({required this.question, required this.answer, this.imagePath});
}
